/*
 * @(#)FolderChooserUI.java 10/9/2005
 *
 * Copyright 2002 - 2005 JIDE Software Inc. All rights reserved.
 */
package com.jidesoft.plaf;

public interface FolderChooserUI {
}
