/**
 * The package contains additional ComponentUI for JIDE components.
 */
package com.jidesoft.plaf;