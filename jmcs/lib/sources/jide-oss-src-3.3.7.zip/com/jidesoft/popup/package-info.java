/**
 * The package contains JidePopup class for JIDE Common Layer.
 */
package com.jidesoft.popup;