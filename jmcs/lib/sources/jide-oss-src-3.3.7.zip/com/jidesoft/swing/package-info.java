/**
 * The package contains many based classes we added on top of Swing for JIDE Common Layer.
 */
package com.jidesoft.swing;