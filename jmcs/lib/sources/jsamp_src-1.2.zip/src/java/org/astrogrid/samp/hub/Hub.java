package org.astrogrid.samp.hub;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.astrogrid.samp.SampUtils;
import org.astrogrid.samp.httpd.UtilServer;
import org.astrogrid.samp.web.WebHubProfileFactory;
import org.astrogrid.samp.xmlrpc.StandardHubProfile;
import org.astrogrid.samp.xmlrpc.StandardHubProfileFactory;
import org.astrogrid.samp.xmlrpc.XmlRpcKit;

/**
 * Class which starts and stops a hub and its associated profiles.
 * Static methods are provided for starting a hub in the current or an
 * external JVM, and a <code>main()</code> method is provided for
 * use from the command line.
 *
 * <p>Some of the static methods allow you to indicate which hub profiles
 * should be used, others use a default.  The default list can be set
 * programmatically by using the {@link #setDefaultProfileClasses} method
 * or externally by using the {@value #HUBPROFILES_PROP} system property.
 * So, for instance, running an application with
 * <code>-Djsamp.hub.profiles=web,std</code> will cause it to run hubs
 * using both the Standard and Web profiles if it does not explicitly choose
 * profiles.
 *
 * @author   Mark Taylor
 * @since    31 Jan 2011
 */
public class Hub {

    private final HubService service_;
    private final HubProfile[] profiles_;
    private static Class[] defaultDefaultProfileClasses_ = {
        StandardHubProfile.class
    };
    private static Class[] defaultProfileClasses_ =
        createDefaultProfileClasses();
    private static final Logger logger_ =
        Logger.getLogger( Hub.class.getName() );

    /**
     * System property name for supplying default profiles ({@value}).
     * The value of this property, if any, will be fed to 
     * {@link #parseProfileList}.
     */
    public static final String HUBPROFILES_PROP = "jsamp.hub.profiles";

    /**
     * Constructor.
     *
     * @param   service   hub service
     * @param   profiles   hub profiles for access from clients
     */
    public Hub( HubService service, HubProfile[] profiles ) {
        service_ = service;
        profiles_ = profiles == null ? createDefaultProfiles() : profiles;
    }

    /**
     * Starts this hub and its profiles running.
     */
    public void start() throws IOException {
        logger_.info( "Starting hub service" );
        service_.start();
        int nStarted = 0;
        try {
            for ( int i = 0; i < profiles_.length; i++ ) {
                logger_.info( "Starting hub profile " + profiles_[ i ] );
                profiles_[ i ].start( service_ );
                nStarted++;
            }
        }
        catch ( IOException e ) {
            for ( int i = 0; i < nStarted; i++ ) {
                try {
                    profiles_[ i ].shutdown();
                }
                catch ( Throwable e2 ) {
                }
            }
            try {
                service_.shutdown();
            }
            catch ( Throwable e2 ) {
            }
            throw e;
        }
    }

    /**
     * Stops this hub and its profiles running.
     */
    public void shutdown() {
        service_.shutdown();
        for ( int i = 0; i < profiles_.length; i++ ) {
            try {
                profiles_[ i ].shutdown();
            }
            catch ( IOException e ) {
            }
        }
    }

    /**
     * Returns a standard list of known HubProfileFactories.
     * This is used when parsing hub profile lists
     * ({@link #parseProfileList} to supply the well-known named profiles.
     *
     * @return   array of known hub profile factories
     */
    public static HubProfileFactory[] getKnownHubProfileFactories() {
        return new HubProfileFactory[] {
            new StandardHubProfileFactory(),
            new WebHubProfileFactory(),
        };
    }

    /**
     * Returns a copy of the default set of HubProfile classes used
     * when a hub is run and the list of profiles is not set explicitly.
     * Each element should be an implementation of {@link HubProfile}
     * with a no-arg constructor.
     *
     * @return   array of hub profile classes
     */
    public static Class[] getDefaultProfileClasses() {
        return (Class[]) defaultProfileClasses_.clone();
    }

    /**
     * Sets the default set of HubProfile classes.
     *
     * @param  dfltProfileClasses  array to be returned by
     *         getDefaultProfileClasses
     */
    public static void setDefaultProfileClasses( Class[] dfltProfileClasses ) {
        for ( int ip = 0; ip < dfltProfileClasses.length; ip++ ) {
            Class clazz = dfltProfileClasses[ ip ];
            if ( ! HubProfile.class.isAssignableFrom( clazz ) ) {
                throw new IllegalArgumentException( "Class " + clazz.getName()
                                                  + " not a HubProfile" );
            }
        }
        defaultProfileClasses_ = (Class[]) dfltProfileClasses.clone();
    }

    /**
     * Invoked at class load time to come up with the list of hub 
     * profiles to use when no profiles are specified explicitly.
     * By default this is just the standard profile, but if the
     * {@link #HUBPROFILES_PROP} system property is defined its value
     * is used instead.
     *
     * @return  default array of hub profile classes
     */
    private static Class[] createDefaultProfileClasses() {
        String listTxt = System.getProperty( HUBPROFILES_PROP );
        if ( listTxt != null ) {
            HubProfileFactory[] facts = parseProfileList( listTxt );
            Class[] clazzes = new Class[ facts.length ];
            for ( int i = 0; i < facts.length; i++ ) {
                clazzes[ i ] = facts[ i ].getHubProfileClass();
            }
            return clazzes;
        }
        else {
            return defaultDefaultProfileClasses_;
        }
    }

    /**
     * Parses a string representing a list of hub profiles.
     * The result is an array of HubProfileFactories.
     * The list is comma-separated, and each element may be
     * <em>either</em> the {@link HubProfileFactory#getName name}
     * of a HubProfileFactory
     * <em>or</em> the classname of a {@link HubProfile} implementation
     * with a suitable no-arg constructor.
     *
     * @param  listTxt  comma-separated list
     * @return  array of hub profile factories
     * @throws   IllegalArgumentException  if unknown
     */
    public static HubProfileFactory[] parseProfileList( String listTxt ) {
        String[] txtItems = listTxt == null || listTxt.trim().length() == 0
                          ? new String[ 0 ]
                          : listTxt.split( "," );
        List factoryList = new ArrayList();
        for ( int i = 0; i < txtItems.length; i++ ) {
            factoryList.add( parseProfileClass( txtItems[ i ] ) );
        }
        return (HubProfileFactory[])
               factoryList.toArray( new HubProfileFactory[ 0 ] );
    }

    /**
     * Parses a string representing a hub profile.  Each element may be
     * <em>either</em> the {@link HubProfileFactory#getName name}
     * of a HubProfileFactory
     * <em>or</em> the classname of a {@link HubProfile} implementation
     * with a suitable no-arg constructor.
     *
     * @param  txt  string
     * @return  hub profile factory
     * @throws   IllegalArgumentException  if unknown
     */
    private static HubProfileFactory parseProfileClass( String txt ) {
        HubProfileFactory[] profFacts = getKnownHubProfileFactories();
        for ( int i = 0; i < profFacts.length; i++ ) {
            if ( txt.equals( profFacts[ i ].getName() ) ) {
                return profFacts[ i ];
            }
        }
        final Class clazz;
        try {
            clazz = Class.forName( txt );
        }
        catch ( ClassNotFoundException e ) {
            throw (IllegalArgumentException)
                  new IllegalArgumentException( "No known hub/class " + txt )
                 .initCause( e );
        }
        if ( HubProfile.class.isAssignableFrom( clazz ) ) {
            return new HubProfileFactory() {
                public Class getHubProfileClass() {
                    return clazz;
                }
                public String[] getFlagsUsage() {
                    return new String[ 0 ];
                }
                public String getName() {
                    return clazz.getName();
                }
                public HubProfile createHubProfile( List flagList )
                        throws IOException {
                    try {
                        return (HubProfile) clazz.newInstance();
                    }
                    catch ( IllegalAccessException e ) {
                        throw (IOException)
                              new IOException( "Can't create " + clazz.getName()
                                             + " instance" )
                             .initCause( e );
                    }
                    catch ( InstantiationException e ) {
                        throw (IOException)
                              new IOException( "Can't create " + clazz.getName()
                                             + " instance" )
                             .initCause( e );
                    }
                    catch ( ExceptionInInitializerError e ) {
                        Throwable cause = e.getCause();
                        if ( cause instanceof IOException ) {
                            throw (IOException) cause;
                        }
                        else {
                            throw (IOException)
                                  new IOException( "Can't create "
                                                 + clazz.getName()
                                                 + " instance" )
                                 .initCause( e );
                        }
                    }
                }
            };
        }
        else {
            throw new IllegalArgumentException( clazz + " is not a "
                                              + HubProfile.class.getName() );
        }
    }

    /**
     * Returns an array of default Hub Profiles.
     * This is the result of calling the no-arg constructor
     * for each element of the result of {@link #getDefaultProfileClasses}.
     *
     * @return   array of hub profiles to use by default
     */
    public static HubProfile[] createDefaultProfiles() {
        List hubProfileList = new ArrayList();
        for ( int ip = 0; ip < defaultProfileClasses_.length; ip++ ) {
            Class clazz = defaultProfileClasses_[ ip ];
            try {
                hubProfileList.add( (HubProfile) clazz.newInstance() );
            }
            catch ( ClassCastException e ) {
                logger_.warning( "No hub profile " + clazz.getName()
                               + " - not a " + HubProfile.class.getName() );
            }
            catch ( InstantiationException e ) {
                logger_.warning( "No hub profile " + clazz.getName()
                               + " - failed to instantiate (" + e + ")" );
            }
            catch ( IllegalAccessException e ) {
                logger_.warning( "No hub profile " + clazz.getName()
                               + " - inaccessible constructor (" + e + ")" );
            }
            catch ( ExceptionInInitializerError e ) {
                logger_.warning( "No hub profile " + clazz.getName()
                               + " - construction error"
                               + " (" + e.getCause() + ")" );
            }
        }
        return (HubProfile[]) hubProfileList.toArray( new HubProfile[ 0 ] );
    }

    /**
     * Starts a SAMP hub with a given set of profiles.
     * The returned hub is running (<code>start</code> has been called).
     *
     * <p>If the hub mode corresponds to one of the GUI options,
     * one of two things will happen.  An attempt will be made to install
     * an icon in the "system tray"; if this is successful, the attached
     * popup menu will provide options for displaying the hub window and
     * for shutting it down.  If no system tray is available, the hub window
     * will be posted directly, and the hub will shut down when this window
     * is closed.  System tray functionality is only available when running
     * under Java 1.6 or later, and when using a suitable display manager.
     *
     * @param   hubMode  hub mode
     * @param   profiles   SAMP profiles to support; if null a default set
     *                     will be used
     * @return  running hub
     */
    public static Hub runHub( HubServiceMode hubMode, HubProfile[] profiles )
            throws IOException {
        final Hub[] runners = new Hub[ 1 ];
        HubService hubService =
            hubMode.createHubService( KeyGenerator.createRandom(), runners );
        final Hub hub = new Hub( hubService, profiles );
        hub.start();
        runners[ 0 ] = hub;
        Runtime.getRuntime().addShutdownHook( new Thread( "Hub Terminator" ) {
            public void run() {
                hub.shutdown();
            }
        } );
        return hub;
    }

    /**
     * Starts a SAMP hub with a default set of profiles.
     * This convenience method invokes <code>runHub(hubMode,null)</code>.
     *
     * @param   hubMode  hub mode
     * @return  running hub
     * @see    #runHub(HubServiceMode,HubProfile[])
     */
    public static Hub runHub( HubServiceMode hubMode ) throws IOException {
        return runHub( hubMode, null );
    }

    /**
     * Attempts to start a hub in a new JVM with a given set
     * of profiles.  The resulting hub can therefore outlast the
     * lifetime of the current application.
     * Because of the OS interaction required, it's hard to make this
     * bulletproof, and it may fail without an exception, but we do our best.
     *
     * @param   hubMode  hub mode
     * @param   profileClasses  classes which implement {@link HubProfile}
     *          and have a no-arg constructor, determining which profiles
     *          the hub will support;  if null, the default set from
     *          the current JVM is used
     * @see     #checkExternalHubAvailability
     */
    public static void runExternalHub( HubServiceMode hubMode,
                                       Class[] profileClasses )
            throws IOException {
        String classpath = System.getProperty( "java.class.path" );
        if ( classpath == null || classpath.trim().length() == 0 ) {
            throw new IOException( "No classpath available - JNLP context?" );
        }
        File javaHome = new File( System.getProperty( "java.home" ) );
        File javaExec = new File( new File( javaHome, "bin" ), "java" );
        String javacmd = ( javaExec.exists() && ! javaExec.isDirectory() )
                       ? javaExec.toString()
                       : "java";
        String[] propagateProps = new String[] {
            XmlRpcKit.IMPL_PROP,
            UtilServer.PORT_PROP,
            SampUtils.LOCALHOST_PROP,
            HUBPROFILES_PROP,
            "java.awt.Window.locationByPlatform",
        };
        List argList = new ArrayList();
        argList.add( javacmd );
        for ( int ip = 0; ip < propagateProps.length; ip++ ) {
            String propName = propagateProps[ ip ];
            String propVal = System.getProperty( propName );
            if ( propVal != null ) {
                argList.add( "-D" + propName + "=" + propVal );
            }
        }
        argList.add( "-classpath" );
        argList.add( classpath );
        argList.add( Hub.class.getName() );
        argList.add( "-mode" );
        argList.add( hubMode.toString() );
        if ( profileClasses != null ) {
            argList.add( "-profiles" );
            StringBuffer profArg = new StringBuffer();
            for ( int ip = 0; ip < profileClasses.length; ip++ ) {
                if ( ip > 0 ) {
                    profArg.append( ',' );
                }
                profArg.append( profileClasses[ ip ].getName() );
            }
            argList.add( profArg.toString() );
        }
        String[] args = (String[]) argList.toArray( new String[ 0 ] );
        StringBuffer cmdbuf = new StringBuffer();
        for ( int iarg = 0; iarg < args.length; iarg++ ) {
            if ( iarg > 0 ) {
                cmdbuf.append( ' ' );
            }
            cmdbuf.append( args[ iarg ] );
        }
        logger_.info( "Starting external hub" );
        logger_.info( cmdbuf.toString() );
        execBackground( args );
    }

    /**
     * Attempts to run a hub in a new JVM with a default set of profiles.
     * The default set is taken from that in this JVM.
     * This convenience method invokes 
     * <code>runExternalHub(hubMode,null)</code>.
     *
     * @param   hubMode  hub mode
     * @see     #runExternalHub(HubServiceMode,java.lang.Class[])
     */
    public static void runExternalHub( HubServiceMode hubMode )
            throws IOException {
        runExternalHub( hubMode, null );
    }

    /**
     * Attempts to determine whether an external hub can be started using
     * {@link #runExternalHub runExternalHub}.
     * If it can be determined that such an
     * attempt would fail, this method will throw an exception with
     * an informative message.  This method succeeding is not a guarantee
     * that an external hub can be started successfullly.
     * The behaviour of this method is not expected to change over the
     * lifetime of a given JVM.
     */
    public static void checkExternalHubAvailability() throws IOException {
        String classpath = System.getProperty( "java.class.path" );
        if ( classpath == null || classpath.trim().length() == 0 ) {
            throw new IOException( "No classpath available - JNLP context?" );
        }
        if ( System.getProperty( "jnlpx.jvm" ) != null ) {
            throw new IOException( "Running under WebStart"
                                 + " - external hub not likely to work" );
        }
    }
    
    /**
     * Main method, which allows configuration of which profiles will run
     * and configuration of those individual profiles.
     * Use the <code>-h</code> flag for usage.
     */
    public static void main( String[] args ) {
        try {
            int status = runMain( args );
            if ( status != 0 ) {
                System.exit( status );
            }
        }

        // Explicit exit on error may be necessary to kill Swing.
        catch ( Throwable e ) {
            e.printStackTrace();
            System.exit( 2 );
        }
    }

    /**
     * Invoked by main.
     * In case of a usage error, it returns a non-zero value, but does not
     * call System.exit.
     *
     * @param   args  command-line argument array
     * @return  non-zero for error completion
     */
    public static int runMain( String[] args ) throws IOException {
        HubProfileFactory[] knownProfileFactories =
            getKnownHubProfileFactories();

        // Assemble usage message.
        StringBuffer pbuf = new StringBuffer();
        pbuf.append( "-profiles " );
        for ( int ip = 0; ip < knownProfileFactories.length; ip++ ) {
            pbuf.append( knownProfileFactories[ ip ].getName() )
                .append( '|' );
        }
        pbuf.append( "<hubprofile-class>" )
            .append( "[,...]" );
        String profilesUsage = pbuf.toString();
        StringBuffer ubuf = new StringBuffer();
        ubuf.append( "\n   Usage:" )
            .append( "\n      " )
            .append( Hub.class.getName() )
            .append( "\n           " )
            .append( " [-help]" )
            .append( " [-/+verbose]" )
            .append( "\n           " )
            .append( " [-mode " );
        HubServiceMode[] modes = HubServiceMode.getAvailableModes();
        for ( int im = 0; im < modes.length; im++ ) {
            if ( im > 0 ) {
                ubuf.append( '|' );
            }
            ubuf.append( modes[ im ].getName() );
        }
        ubuf.append( ']' )
            .append( "\n           " )
            .append( " [" )
            .append( profilesUsage )
            .append( "]" );
        for ( int ip = 0; ip < knownProfileFactories.length; ip++ ) {
            List pusageList =
                 new ArrayList( Arrays.asList( knownProfileFactories[ ip ]
                                              .getFlagsUsage() ) );
            while ( ! pusageList.isEmpty() ) {
                StringBuffer sbuf = new StringBuffer()
                            .append( "\n           " );
                for ( Iterator it = pusageList.iterator(); it.hasNext(); ) {
                    String pusage = (String) it.next();
                    if ( sbuf.length() + pusage.length() < 78 ) {
                        sbuf.append( ' ' )
                            .append( pusage );
                        it.remove();
                    }
                    else {
                        break;
                    }
                }
                ubuf.append( sbuf );
            }
        }
        ubuf.append( '\n' );
        String usage = ubuf.toString();

        // Get default hub mode.
        HubServiceMode hubMode = HubServiceMode.MESSAGE_GUI;
        if ( ! Arrays.asList( HubServiceMode.getAvailableModes() )
                     .contains( hubMode ) ) {
            hubMode = HubServiceMode.NO_GUI;
        }

        // Parse general command-line arguments.
        List argList = new ArrayList( Arrays.asList( args ) );
        int verbAdjust = 0;
        String stdSecret = null;
        boolean stdHttplock = false;
        String webAuth = "swing";
        String webLog = "none";
        boolean webRemote = false;
        String profilesTxt = null;
        for ( Iterator it = argList.iterator(); it.hasNext(); ) {
            String arg = (String) it.next();
            if ( arg.equals( "-mode" ) && it.hasNext() ) {
                it.remove();
                String mode = (String) it.next();
                it.remove();
                hubMode = HubServiceMode.getModeFromName( mode );
                if ( hubMode == null ) {
                    System.err.println( "Unkown mode " + mode );
                    System.err.println( usage );
                    return 1;
                }
            }
            else if ( arg.equals( "-profiles" ) ) {
                it.remove();
                if ( it.hasNext() ) {
                    profilesTxt = (String) it.next();
                    it.remove();
                }
                else {
                    System.err.println( usage );
                    return 1;
                }
            }
            else if ( arg.equals( "-v" ) || arg.equals( "-verbose" ) ) {
                it.remove();
                verbAdjust--;
            }
            else if ( arg.equals( "+v" ) || arg.equals( "+verbose" ) ) {
                it.remove();
                verbAdjust++;
            }
            else if ( arg.equals( "-h" ) || arg.equals( "-help" ) ) {
                it.remove();
                System.out.println( usage );
                return 0;
            }
        }

        // Adjust logging in accordance with verboseness flags.
        int logLevel = Level.WARNING.intValue() + 100 * verbAdjust;
        Logger.getLogger( "org.astrogrid.samp" )
              .setLevel( Level.parse( Integer.toString( logLevel ) ) );

        // Assemble list of profile factories to use.
        final HubProfile[] profiles;
        if ( profilesTxt == null ) {
            profiles = createDefaultProfiles();
        }
        else {
            HubProfileFactory[] pfacts;
            try {
                pfacts = parseProfileList( profilesTxt );
            }
            catch ( IllegalArgumentException e ) {
                System.err.println( e.getMessage() );
                System.err.println( "Usage: " + profilesUsage );
                return 1;
            }
            profiles = new HubProfile[ pfacts.length ];
            for ( int i = 0; i < pfacts.length; i++ ) {
                HubProfileFactory pfact = pfacts[ i ];
                try {
                    profiles[ i ] = pfact.createHubProfile( argList );
                }
                catch ( RuntimeException e ) {
                    System.err.println( "Error configuring profile "
                                      + pfact.getName() + ":\n"
                                      + e.getMessage() );
                    return 1;
                }
             
            }
        }

        // Check all command line args have been used.
        if ( ! argList.isEmpty() ) {
            System.err.println( "Some args not used " + argList );
            System.err.println( usage );
            return 1;
        }

        // Start hub service and install profile-specific interfaces.
        runHub( hubMode, profiles );

        // For non-GUI case block indefinitely otherwise the hub (which uses
        // a daemon thread) will just exit immediately.
        if ( hubMode.isDaemon() ) {
            Object lock = new String( "Indefinite" );
            synchronized ( lock ) {
                try {
                    lock.wait();
                }
                catch ( InterruptedException e ) {
                }
            }
        }

        // Success return.
        return 0;
    }

    /**
     * Executes a command in a separate process, and discards any stdout
     * or stderr output generated by it.
     * Simply calling <code>Runtime.exec</code> can block the process
     * until its output is consumed.
     *
     * @param  cmdarray  array containing the command to call and its args
     */
    private static void execBackground( String[] cmdarray ) throws IOException {
        Process process = Runtime.getRuntime().exec( cmdarray );
        discardBytes( process.getInputStream() );
        discardBytes( process.getErrorStream() );
    }

    /**
     * Ensures that any bytes from a given input stream are discarded.
     *
     * @param  in  input stream
     */
    private static void discardBytes( final InputStream in ) {
        Thread eater = new Thread( "StreamEater" ) {
            public void run() {
                try {
                    while ( in.read() >= 0 ) {}
                    in.close();
                }
                catch ( IOException e ) {
                }
            }
        };
        eater.setDaemon( true );
        eater.start();
    }
}
